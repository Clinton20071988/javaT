package Scripts;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;
public class Xpaths {
	WebDriver driver;
	
	@SuppressWarnings("unchecked")
	@Test(priority=1)
		
		public <WebElement> void ValidateXpath() 
		{
		
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\clinton_fernandes\\Downloads\\geckodriver-v0.24.0-win64\\geckodriver.exe");
		driver = new FirefoxDriver();
		driver.get("https://www.trymyui.com/");
		
		//1.Assert by Text
		Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"text-3\"]/div/ul/li[3]/a")).getText(), "Get Paid to Test");
		System.out.println("Assertion worked");
		//2.Assert by Link
		Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"text-3\"]/div/ul/li[3]/a")).getAttribute("href"), "https://www.trymyui.com/worker/signup");
		
		//Assert by Button Value
		WebElement submit = (WebElement) driver.findElement(By.xpath("//*[@id=\"post-2\"]/div/section[1]/div/div/a[2]"));
	    Assert.assertEquals("FREE TRIAL", ((org.openqa.selenium.WebElement) submit).getText());
	    driver.quit();
		}
		}

